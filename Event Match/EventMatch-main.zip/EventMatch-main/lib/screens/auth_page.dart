import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'home_page.dart'; // Replace with the correct path to your HomePage file

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final TextEditingController _emailControllerLogin = TextEditingController();
  final TextEditingController _passwordControllerLogin =
      TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  final TextEditingController _nameController = TextEditingController();

  bool isLogin = true;

  static const Color brandColor = Color(0xFFE86343);

  Future<void> signupWithEmailPass(String emailAddress, String password) async {
    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: emailAddress,
        password: password,
      );
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        print('The password provided is too weak.');
      } else if (e.code == 'email-already-in-use') {
        print('The account already exists for that email.');
      }
    } catch (e) {
      print(e.hashCode);
    }
  }

  Future<void> SigninWithEmailPass(String emailAddress, String password) async {
    try {
      await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: emailAddress, password: password);
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        print('No user found for that email.');
      } else if (e.code == 'wrong-password') {
        print('Wrong password provided for that user.');
      }
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showAccountNotFoundDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('No User Found'),
        content: const Text(
            'No account exists with this email. Do you want to create a new account?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                isLogin = false;
              });
            },
            child: const Text('Create Account'),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required IconData icon,
    required TextEditingController controller,
    required String label,
    bool isPassword = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(top: 8),
      child: TextFormField(
        controller: controller,
        obscureText: isPassword,
        style: const TextStyle(fontSize: 16),
        decoration: InputDecoration(
          prefixIcon: Icon(icon),
          labelText: label,
          labelStyle: const TextStyle(fontSize: 16, color: Colors.grey),
          alignLabelWithHint: true,
          floatingLabelBehavior: FloatingLabelBehavior.auto,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Colors.grey),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Colors.grey),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: brandColor),
          ),
          filled: true,
          fillColor: Colors.white,
        ),
      ),
    );
  }

  Widget _buildSocialButton({
    required String text,
    IconData? icon,
    Widget? iconWidget,
    Color iconColor = Colors.black87,
    required VoidCallback onPressed,
    Color backgroundColor = Colors.white,
    Color textColor = Colors.black87,
    bool outlined = false,
  }) {
    final buttonStyle = outlined
        ? OutlinedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 12),
            foregroundColor: iconColor,
            side: BorderSide(color: iconColor),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          )
        : ElevatedButton.styleFrom(
            backgroundColor: backgroundColor,
            padding: const EdgeInsets.symmetric(vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: const BorderSide(color: Colors.black12),
            ),
          );

    final content = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        iconWidget ??
            (icon != null
                ? Icon(icon, color: iconColor, size: 20)
                : const SizedBox.shrink()),
        if (iconWidget != null || icon != null) const SizedBox(width: 12),
        Text(
          text,
          style: TextStyle(
            color: outlined ? iconColor : textColor,
            fontSize: 16,
          ),
        ),
      ],
    );

    return SizedBox(
      width: double.infinity,
      child: outlined
          ? OutlinedButton(
              onPressed: onPressed,
              style: buttonStyle,
              child: content,
            )
          : ElevatedButton(
              onPressed: onPressed,
              style: buttonStyle,
              child: content,
            ),
    );
  }

  Widget _buildPrimaryButton({
    required String text,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: brandColor,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        child: Text(
          text,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _buildSignInForm() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Image.asset("images/EventMatch_NoBg.jpg", height: 100),
        const SizedBox(height: 16),
        _buildTextField(
          icon: Icons.email,
          controller: _emailControllerLogin,
          label: 'Email',
        ),
        const SizedBox(height: 16),
        _buildTextField(
          icon: Icons.lock,
          controller: _passwordControllerLogin,
          label: 'Password',
          isPassword: true,
        ),
        const SizedBox(height: 24),
        _buildPrimaryButton(
          text: 'Sign in',
          onPressed: () {
            print("okay");
            SigninWithEmailPass(_emailControllerLogin.text.trim(),
                _passwordControllerLogin.text.trim());
          },
        ),
        const SizedBox(height: 16),
        TextButton(
          onPressed: () {},
          child: Text(
            'Forgot Password?',
            style: TextStyle(
              color: brandColor,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(
            'Don\'t Have an Account?',
            style: TextStyle(
              color: brandColor,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(
            width: 6,
          ),
          GestureDetector(
            child: Text(
              "Create Account!",
              style: TextStyle(color: Colors.blue),
            ),
            onTap: () {
              setState(() {
                isLogin = false;
              });
            },
          )
        ]),
      ],
    );
  }

  Widget _buildSignUpForm() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Image.asset("images/EventMatch_NoBg.jpg", height: 100),
        const SizedBox(height: 16),
        _buildTextField(
          icon: Icons.person,
          controller: _nameController,
          label: 'Name',
        ),
        const SizedBox(height: 16),
        _buildTextField(
          icon: Icons.email,
          controller: _emailController,
          label: 'Email',
        ),
        const SizedBox(height: 16),
        _buildTextField(
          icon: Icons.lock,
          controller: _passwordController,
          label: 'Password',
          isPassword: true,
        ),
        const SizedBox(height: 24),
        _buildPrimaryButton(
          text: 'Sign Up',
          onPressed: () {
            print("okay");
            signupWithEmailPass(
                _emailController.text.trim(), _passwordController.text.trim());
          },
        ),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(
            'Already Have an Account?',
            style: TextStyle(
              color: brandColor,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(
            width: 6,
          ),
          GestureDetector(
            child: Text(
              "Login",
              style: TextStyle(color: Colors.blue),
            ),
            onTap: () {
              setState(() {
                isLogin = true;
              });
            },
          )
        ]),

        // _buildSocialButton(
        //   text: 'Continue with Google',
        //   iconWidget: Image.asset(
        //     'images/googlelogo.webp',
        //     height: 24,
        //   ),
        //   onPressed: () {},
        // ),
        // const SizedBox(height: 12),
        // _buildSocialButton(
        //   text: 'Continue with Email',
        //   icon: Icons.mail_outline,
        //   iconColor: Colors.black87,
        //   onPressed: () {},
        // ),
        // const SizedBox(height: 12),
        // _buildSocialButton(
        //   text: 'Continue with Apple',
        //   icon: Icons.apple,
        //   iconColor: Colors.black,
        //   onPressed: () {},
        // ),
        // Padding(
        //   padding: const EdgeInsets.symmetric(vertical: 24),
        //   child: Row(
        //     children: const [
        //       Expanded(child: Divider()),
        //       Padding(
        //         padding: EdgeInsets.symmetric(horizontal: 16),
        //         child: Text(
        //           'or',
        //           style: TextStyle(color: Colors.grey),
        //         ),
        //       ),
        //       Expanded(child: Divider()),
        //     ],
        //   ),
        // ),
        // _buildSocialButton(
        //   text: 'Continue with Facebook',
        //   icon: Icons.facebook,
        //   iconColor: Colors.blue,
        //   onPressed: () {},
        // ),
        // const SizedBox(height: 24),
        // _buildPrimaryButton(
        //   text: 'Sign up',
        //   onPressed: () {
        //     WidgetsBinding.instance.addPostFrameCallback((_) {
        //       Navigator.push(
        //         context,
        //         MaterialPageRoute(builder: (context) => const HomePage()),
        //       );
        //     });
        //   },
        // ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: brandColor,
      resizeToAvoidBottomInset:
          true, // This ensures the layout adjusts when the keyboard appears.
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(24),
              child: Row(
                children: const [
                  Text(
                    'EventMatch',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(24),
                    topRight: Radius.circular(24),
                  ),
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(24),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          TextButton(
                            onPressed: () => setState(() => isLogin = true),
                            child: Text(
                              'Sign In',
                              style: TextStyle(
                                color: isLogin ? brandColor : Colors.grey,
                                fontWeight: isLogin
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                                fontSize: 16,
                              ),
                            ),
                          ),
                          TextButton(
                            onPressed: () => setState(() => isLogin = false),
                            child: Text(
                              'Sign up',
                              style: TextStyle(
                                color: !isLogin ? brandColor : Colors.grey,
                                fontWeight: !isLogin
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 24, vertical: 24),
                          child:
                              isLogin ? _buildSignInForm() : _buildSignUpForm(),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 24,
                        right: 24,
                        bottom: MediaQuery.of(context).viewInsets.bottom == 0
                            ? 16
                            : 0,
                        top: 16,
                      ),
                      child: const Text(
                        'By proceeding, you agree to EventMatch\'s Privacy Policy, User Agreement and T&Cs',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 12,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
