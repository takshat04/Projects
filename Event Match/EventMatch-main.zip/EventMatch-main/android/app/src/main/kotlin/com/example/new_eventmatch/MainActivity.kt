package com.example.new_eventmatch

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
