const Mentee = require('../models/Mentee');

exports.getMentees = async (req, res) => {
  try {
    const mentees = await Mentee.find();
    res.json(mentees);
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
};
