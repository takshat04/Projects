const Mentor = require('../models/Mentor');

// Get all mentors
const getMentors = async (req, res) => {
    try {
        const mentors = await Mentor.find();
        res.json(mentors);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// Add a new mentor
const addMentor = async (req, res) => {
    const mentor = new Mentor(req.body);
    try {
        const newMentor = await mentor.save();
        res.status(201).json(newMentor);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
};

module.exports = { getMentors, addMentor };
