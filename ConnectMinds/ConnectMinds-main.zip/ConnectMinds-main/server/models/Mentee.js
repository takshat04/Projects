const mongoose = require('mongoose');

const MenteeSchema = new mongoose.Schema({
  name: String,
  interests: [String],
  bookedSlots: [String],
});

module.exports = mongoose.model('Mentee', MenteeSchema);
