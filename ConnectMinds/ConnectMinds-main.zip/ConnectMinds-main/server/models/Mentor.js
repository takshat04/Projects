const mongoose = require('mongoose');

const MentorSchema = new mongoose.Schema({
  name: String,
  expertise: String,
  availableSlots: [String],
});

module.exports = mongoose.model('Mentor', MentorSchema);
