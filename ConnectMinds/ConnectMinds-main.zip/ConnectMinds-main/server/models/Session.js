const mongoose = require('mongoose');

const SessionSchema = new mongoose.Schema({
  mentorId: mongoose.Schema.Types.ObjectId,
  menteeId: mongoose.Schema.Types.ObjectId,
  scheduledTime: Date,
});

module.exports = mongoose.model('Session', SessionSchema
