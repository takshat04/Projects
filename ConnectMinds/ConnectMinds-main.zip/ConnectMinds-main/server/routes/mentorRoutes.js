const express = require('express');
const router = express.Router();
const { getMentors, addMentor } = require('../controllers/mentorController');

router.get('/', getMentors);
router.post('/', addMentor);

module.exports = router;
