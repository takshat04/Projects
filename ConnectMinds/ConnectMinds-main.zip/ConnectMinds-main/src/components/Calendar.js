// src/components/Calendar.js
import React from 'react';
import { InlineWidget } from 'react-calendly';

export const Calendar = () => {
  return (
    <div>
      <h2>Book a Session with a Mentor</h2>
      <InlineWidget url="https://calendly.com/your_organization" />
    </div>
  );
};