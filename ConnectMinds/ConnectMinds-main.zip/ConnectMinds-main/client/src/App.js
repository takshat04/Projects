import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Login from './components/Login';
import Signup from './components/Signup';
import MentorList from './components/MentorList';
import MentorBooking from './components/MentorBooking';
import MentorAssessment from './components/MentorAssessment';
import About from './components/About';
import './styles/App.css';

function App() {
  return (
    <Router>
      <div className="app">
        <Navbar />
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/mentors" element={<MentorList />} />
          <Route path="/mentor-booking" element={<MentorBooking />} />
          <Route path="/mentor-assessment" element={<MentorAssessment />} />
          <Route path="/about" element={<About />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
