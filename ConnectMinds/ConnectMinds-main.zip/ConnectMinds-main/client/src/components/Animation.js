// src/components/Animation.js
import React, { useEffect } from 'react';
import createScene from '../threejs/AnimationScene';
import '../styles/Animation.css';

function Animation() {
  useEffect(() => {
    createScene();
  }, []);

  return (
    <div id="threejs-animation">
      {/* Three.js animation will be rendered here */}
    </div>
  );
}

export default Animation;
