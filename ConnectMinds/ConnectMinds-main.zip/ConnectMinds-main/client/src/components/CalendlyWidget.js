import React, { useEffect } from 'react';
import '../styles/CalendlyWidget.css'; // Ensure you have a CSS file for styling

const CalendlyWidget = () => {
  useEffect(() => {
    // Load the Calendly script when the component mounts
    const script = document.createElement('script');
    script.src = 'https://assets.calendly.com/assets/external/widget.js';
    script.async = true;
    document.body.appendChild(script);

    // Cleanup script when component unmounts
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return (
    <div className="calendly-container">
      <h2>Schedule a Session</h2>
      <div
        className="calendly-inline-widget"
        data-url="https://calendly.com/vivekvasani2004/session?background_color=75c476"
        style={{ minWidth: '320px', height: '700px' }}
      ></div>
    </div>
  );
};

export default CalendlyWidget;
