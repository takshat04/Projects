// src/components/Footer.js
import React from 'react';
import '../styles/Footer1.css';

function Footer1() {
  return (
    <footer className="footer1">
      <p>© 2024 ConnectMinds. All rights reserved.</p>
    </footer>
  );
}

export default Footer1;
