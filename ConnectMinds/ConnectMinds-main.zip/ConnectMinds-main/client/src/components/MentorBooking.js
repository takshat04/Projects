import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/MentorBooking.css';

const MentorBooking = () => {
  const navigate = useNavigate();

  const startVideoCall = () => {
    // Replace with your video call logic
    navigate('/video-call');
  };

  return (
    <div className="mentor-booking">
      <h2>Book a Session</h2>
      <button className="book-session-button" onClick={startVideoCall}>
        Book a Session
      </button>
    </div>
  );
};

export default MentorBooking;