    import React, { useState, useEffect } from 'react';
    import '../styles/MentorAssessment.css';

    const MentorAssessment = () => {
    const [selectedAnswers, setSelectedAnswers] = useState({});
    const [codingAnswer, setCodingAnswer] = useState('');
    const [score, setScore] = useState(null);
    const [currentQuestion, setCurrentQuestion] = useState(0);  // Track the current active question
    const [timer, setTimer] = useState(3);  // Set the timer to 30 seconds initially for MCQs
    const [codingTimer, setCodingTimer] = useState(300);  // 5 minutes (300 seconds) for coding question
    const [isCodingQuestion, setIsCodingQuestion] = useState(false);  // Track if coding question is active
    const [isTestSubmitted, setIsTestSubmitted] = useState(false);  // Flag to prevent interaction after test is submitted

    const correctAnswers = {
        0: '3306',
        1: 'CSS',
        2: 'Structured Query Language',
        3: 'final',
        4: 'class MyClass:',
        5: 'append()',
        6: 'urls.py',
        7: 'text-bold',
        8: 'SELECT',
        9: '55',
        10: '&&',
        11: 'printf()',
        12: '# comment',
        13: '<video>',
        14: 'DELETE'
    };

    useEffect(() => {
        let countdown;
        if (!isCodingQuestion && !isTestSubmitted) {
        // MCQ Timer Countdown
        countdown = setInterval(() => {
            setTimer((prevTimer) => {
            if (prevTimer > 0) {
                return prevTimer - 1;
            } else {
                // When timer reaches 0, move to the next question
                handleNextQuestion();
                return 3 ; // Reset timer for next question
            }
            });
        }, 1000);
        }

        if (isCodingQuestion && !isTestSubmitted) {
        // Coding question timer countdown
        countdown = setInterval(() => {
            setCodingTimer((prevTimer) => {
            if (prevTimer > 0) {
                return prevTimer - 1;
            } else {
                handleSubmit();  // Submit the test automatically if coding time runs out
                return 0;
            }
            });
        }, 1000);
        }

        return () => clearInterval(countdown);  // Cleanup interval on component unmount or question change
    }, [currentQuestion, isCodingQuestion, isTestSubmitted]);

    const handleAnswerChange = (questionIndex, answer) => {
        // Only allow answers to the currently active question
        if (currentQuestion === questionIndex && !isTestSubmitted) {
        setSelectedAnswers({
            ...selectedAnswers,
            [questionIndex]: answer,
        });
        }
    };

    const handleNextQuestion = () => {
        if (currentQuestion < Object.keys(correctAnswers).length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setTimer(3);  // Reset timer for the next question
        } else {
        // Move to coding question
        setIsCodingQuestion(true);
        }
    };

    const handleSubmit = (event) => {
        if (event) event.preventDefault();
        setIsTestSubmitted(true);

        // Calculate the MCQ score
        let mcqScore = 0;
        Object.keys(correctAnswers).forEach((index) => {
        if (selectedAnswers[index] === correctAnswers[index]) {
            mcqScore += 1;
        }
        });

        // Check the coding answer
        const isCodingAnswerCorrect = checkCodingAnswer();

        // Total score with coding logic
        const totalScore = mcqScore + (isCodingAnswerCorrect ? 1 : 0);

        setScore({
        mcqScore,
        totalScore,
        isCodingAnswerCorrect,
        });
    };

    // Simplified coding answer checker
    const checkCodingAnswer = () => {
        const correctCode = `def factorial(n):
        if n == 0:
            return 1
        else:
            return n * factorial(n-1)`;

        return codingAnswer.trim() === correctCode.trim();
    };

    return (
        <div className="mentor-assessment">
        <div className="content">
            <h2>Mentor Assessment</h2>
            {!isTestSubmitted && (
            <>
                <form onSubmit={handleSubmit}>
                {!isCodingQuestion ? (
                    <>
                    <h3>Multiple Choice Questions (MCQs)</h3>
                    <div className="mcq-section">
                        {[{ question: 'What is the default port for MySQL?', options: ['3306', '1433', '1521', '5432'] },
                        { question: 'Which language is used to style web pages?', options: ['HTML', 'CSS', 'JavaScript', 'SQL'] },
                        { question: 'What does SQL stand for?', options: ['Structured Query Language', 'Structured Queue Language', 'Sequential Query Language', 'Server Query Language'] },
                        { question: 'Which keyword is used to define a constant in Java?', options: ['final', 'static', 'const', 'let'] },
                        { question: 'What is the correct way to start a class in Python?', options: ['class MyClass:', 'def MyClass:', 'function MyClass:', 'start MyClass:'] },
                        { question: 'Which method is used to insert an element in a Python list?', options: ['insert()', 'push()', 'add()', 'append()'] },
                        { question: 'In Django, which file is responsible for URL routing?', options: ['urls.py', 'views.py', 'models.py', 'admin.py'] },
                        { question: 'Which of the following is NOT a valid CSS property?', options: ['color', 'font-size', 'text-align', 'text-bold'] },
                        { question: 'Which of the following is used to fetch data from a database in SQL?', options: ['SELECT', 'INSERT', 'UPDATE', 'DELETE'] },
                        { question: 'What is the output of 5 + "5" in JavaScript?', options: ['55', '10', 'NaN', 'Error'] },
                        { question: 'Which of the following is a C programming operator for logical AND?', options: ['&&', '&', 'and', '|'] },
                        { question: 'Which function in C is used to print to the console?', options: ['printf()', 'cout', 'System.out.println()', 'print()'] },
                        { question: 'How do you comment a single line in Python?', options: ['// comment', '# comment', '/* comment */', '-- comment'] },
                        { question: 'Which HTML5 tag is used to embed video files?', options: ['<video>', '<media>', '<embed>', '<iframe>'] },
                        { question: 'Which keyword is used to delete a record in SQL?', options: ['DELETE', 'DROP', 'REMOVE', 'TRUNCATE'] }
                        ].map((mcq, index) => (
                        <div key={index} className={`mcq ${currentQuestion === index ? 'active' : 'inactive'}`}>
                            <p>{index + 1}. {mcq.question}</p>
                            <div className="labelDiv">
                            {mcq.options.map((option, i) => (
                                <label key={i}>
                                <input
                                    type="radio"
                                    name={`mcq-${index}`}
                                    value={option}
                                    onChange={() => handleAnswerChange(index, option)}
                                    disabled={currentQuestion !== index}
                                />
                                {option}
                                </label>
                            ))}
                            </div>
                            <div className={`timer-box ${timer <= 10 ? 'pulse' : ''}`}>
                            {currentQuestion === index && (
                            <p className={`timer ${timer <= 10 ? 'warning' : ''}`}>Time left: {timer} seconds</p>
                            )}
                            </div>
                        </div>
                        ))}
                    </div>
                    </>
                ) : (
                    <>
                    <h3>Coding Question</h3>
                    <div className="coding-section">
                        <p>Write a Python function to find the factorial of a number:</p>
                        <textarea
                        placeholder="Write your code here..."
                        value={codingAnswer}
                        onChange={(e) => setCodingAnswer(e.target.value)}
                        disabled={isTestSubmitted}
                        />
                        <div className={`timer-box ${codingTimer <= 10 ? 'pulse' : ''}`}>
                        <p className={`timer ${codingTimer <= 10 ? 'warning' : ''}`}>
                            Time left for coding: {Math.floor(codingTimer / 60)}:{codingTimer % 60 < 10 ? '0' : ''}{codingTimer % 60} minutes
                        </p>
                        </div>

                    </div>
                    </>
                )}
                <button type="submit" className="submit-btn">Submit</button>
                </form>
            </>
            )}

            {/* Display result after submission */}
            {score && (
            <div className="result-box">
                <h3>Test Results</h3>
                <p>MCQ Score: {score.mcqScore} / 15</p>
                <p>Coding Question: {score.isCodingAnswerCorrect ? 'Correct' : 'Incorrect'}</p>
                <p>Total Score: {score.totalScore} / 16</p>
                {score.totalScore >= 12 ? (
                <p className="pass-message" style={{ color: 'green' }}>Congratulations! You passed the test.</p>
                ) : (
                <p className="fail-message" style={{ color: 'red' }}>You did not pass the test. Better luck next time!</p>
                )}
            </div>
            )}
        </div>
        </div>
    );
    };

    export default MentorAssessment;
