import React, { useEffect } from 'react';
import '../styles/MentorList.css';

const mentors = [
  {
    id: 1,
    name: 'John Doe',
    skills: ['JavaScript', 'React', 'Node.js'],
    availability: 'Available',
    fee: '500',
  },
  {
    id: 2,
    name: 'Jane Smith',
    skills: ['Python', 'Machine Learning', 'Data Science'],
    availability: 'Not Available',
  },
  {
    id: 3,
    name: 'Alice Johnson',
    skills: ['HTML', 'CSS', 'Web Design'],
    availability: 'Available',
    fee: '750',
  },
];

// Helper function to load the Calendly script dynamically
const loadCalendlyScript = () => {
  const script = document.createElement('script');
  script.src = 'https://assets.calendly.com/assets/external/widget.js';
  script.async = true;
  document.body.appendChild(script);
};

const MentorList = () => {
  useEffect(() => {
    loadCalendlyScript(); // Load the Calendly script when the component mounts
  }, []);

  const handleBookSession = () => {
    if (window.Calendly) {
      window.Calendly.initPopupWidget({ url: 'https://calendly.com/vivekvasani2004/session' });
    } else {
      console.error('Calendly is not loaded yet.');
    }
  };

  return (
    <div className="mentor-list">
      <h2>Recommended Mentor</h2>
      <ul>
        {mentors.map((mentor) => (
          <li key={mentor.id} className="mentor-item">
            <h3>{mentor.name}</h3>
            <p><strong>Skills:</strong> {mentor.skills.join(', ')}</p>
            <p><strong>Availability:</strong> {mentor.availability}</p>
            {mentor.availability === 'Available' && (
              <button className="book-button" onClick={handleBookSession}>
                Book a Session
              </button>
            )}
            <p><strong>Fee:</strong> {mentor.fee}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MentorList;
