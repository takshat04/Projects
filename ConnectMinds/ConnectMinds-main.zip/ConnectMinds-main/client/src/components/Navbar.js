// src/components/Navbar.js
import React from 'react';
import '../styles/Navbar.css';
import logo from '../assets/download.png'; // Adjust the path according to your folder structure

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="logo">
        <img src={logo} alt="ConnectMinds Logo" />
        <h1>ConnectMinds</h1>
      </div>
      <ul>
        <li><a href="/about">About Us</a></li>
        <li><a href="/">SignUp</a></li>
        <li><a href="/signup">Login</a></li>
        <li><a href="/mentors">Dashboard</a></li>
      </ul>
    </nav>
  );
};

export default Navbar;
