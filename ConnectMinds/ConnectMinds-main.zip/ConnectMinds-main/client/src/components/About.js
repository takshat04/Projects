import React from 'react';
import '../styles/About.css'; // Optional: Create a CSS file for styling

const AboutUs = () => {
  return (
    <div className="about-us">
      <h2>About Us - ConnectMinds</h2>
      <p>Welcome to ConnectMinds, where aspirations meet guidance and potential transforms into success! We are a dedicated platform designed to bridge the gap between mentees and mentors, fostering meaningful connections that inspire growth, learning, and personal development.</p>
      
      <h2>Our Mission</h2>
      <p>At ConnectMinds, our mission is simple yet profound: to empower individuals by providing access to experienced mentors who can offer valuable insights, support, and encouragement. We believe that everyone deserves the opportunity to learn from those who have walked the path before them. Our aim is to create a nurturing environment where knowledge is shared, skills are honed, and dreams are realized.</p>
      
      <h2>Who We Are</h2>
      <p>ConnectMinds was founded by a group of passionate professionals who understand the transformative power of mentorship. With diverse backgrounds spanning various industries, our team is committed to cultivating a community where mentors and mentees can engage, inspire, and uplift one another. We recognize that mentorship is a two-way street, and we strive to create an ecosystem where both parties benefit from shared experiences and perspectives.</p>
      
      <h2>What We Do</h2>
      <p>We provide a user-friendly platform that connects mentees with mentors across a wide range of fields and expertise. Whether you are a student seeking guidance in your academic journey, a young professional navigating your career, or someone looking to explore a new path, ConnectMinds has the right mentor for you.</p>
      
      <h2>Join Us</h2>
      <p>At ConnectMinds, we believe that mentorship is not just about guidance; it's about building lasting relationships that inspire change. We invite you to join our community today. Whether you’re looking to give back as a mentor or seeking support as a mentee, together we can unlock the potential within you and connect the minds that will shape the future.</p>
      
      
    </div>
  );
};

export default AboutUs;
