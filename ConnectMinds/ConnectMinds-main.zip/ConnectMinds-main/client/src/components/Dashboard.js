// src/components/Dashboard.js
import React, { useEffect, useState } from 'react';
import '../styles/Dashboard.css';

const Dashboard = () => {
  const [mentors, setMentors] = useState([]);

  useEffect(() => {
    // Fetch recommended mentors based on the mentee's skill set
    fetch('/api/mentors') // Replace with your API endpoint
      .then(response => response.json())
      .then(data => setMentors(data));
  }, []);

  return (
    <div className="dashboard">
      <h2>Recommended Mentors</h2>
      <ul>
        {mentors.map((mentor) => (
          <li key={mentor.id}>
            <h3>{mentor.name}</h3>
            <p>Skills: {mentor.skills.join(', ')}</p>
            <button>Check Availability</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Dashboard;
