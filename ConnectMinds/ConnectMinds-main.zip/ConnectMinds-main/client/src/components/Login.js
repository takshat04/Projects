import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Login.css';

const Login = () => {
  const [fullName, setFullName] = useState('');
  const [age, setAge] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [resume, setResume] = useState(null);
  const [role, setRole] = useState('mentee'); // Default role
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
    
    // Dummy validation for now
    if (!fullName || !age || !contactNumber || !email || !password || !resume) {
      alert("Please fill out all fields!");
      return;
    }

    // Perform login logic here (e.g., API call)
    // For now, we'll just redirect based on role
    if (role === 'mentor') {
      navigate('/mentor-assessment');  // Navigate to mentor assessment page if the user is a mentor
    } else {
      navigate('/mentors');  // Navigate to mentee page
    }
  };

  const handleFileChange = (event) => {
    setResume(event.target.files[0]);
  };

  return (
    <div className="login-form">
      <h2>SignUp</h2>
      <form onSubmit={handleSubmit}>
        
        {/* Full Name Input */}
        <input
          type="text"
          placeholder="Full Name"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          required
        />
        
        {/* Age Input */}
        <input
          type="number"
          placeholder="Age"
          value={age}
          onChange={(e) => setAge(e.target.value)}
          required
        />
        
        {/* Contact Number Input */}
        <input
          type="tel"
          placeholder="Contact Number"
          value={contactNumber}
          onChange={(e) => setContactNumber(e.target.value)}
          required
        />
        
        {/* Email Input */}
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        
        {/* Password Input */}
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        
        {/* Resume Upload */}
        <input
          type="file"
          placeholder="Upload Resume"
          onChange={handleFileChange}
          required
        />
        
        <div className="role-selection">
  <p>Select Role:</p>
  <div className="role-options">
    <label>
      <input
        type="radio"
        name="role"
        value="mentee"
        checked={role === 'mentee'}
        onChange={() => setRole('mentee')}
        
      />
      Mentee
    </label>
    <label>
      <input
        type="radio"
        name="role"
        value="mentor"
        checked={role === 'mentor'}
        onChange={() => setRole('mentor')}
      />
      Mentor
    </label>
  </div>
</div>

        
        {/* Submit Button */}
        <button type="submit">Singup</button>
      </form>
    </div>
  );
};

export default Login;
