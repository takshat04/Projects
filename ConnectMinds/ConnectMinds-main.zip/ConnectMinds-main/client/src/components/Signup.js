import React from 'react';
import '../styles/Signup.css';
import '../styles/Footer.css';

const Signup = () => {
  return (
    <div className="signup-form">
      <h2>Login</h2>
      <div classname="center">
        <form>
        <input type="email" placeholder="Email" required />
        <input type="password" placeholder="Password" required />
        <div className="forgot-password">
        <a href="/forgot-password">Forgot Password?</a>
      </div>
        <button type="submit">Login</button>
        <br></br>
        <p className = "para">Or Login with:</p>
        <div className="social-login">
            <span><button className="google-button">Google</button></span>
            <span><button className="linkedin-button">LinkedIn</button></span>
          </div>
      </form>
      </div>
    </div>
  );
};

export default Signup;
